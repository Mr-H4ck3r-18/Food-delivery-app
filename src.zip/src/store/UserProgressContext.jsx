import { createContext, useState } from "react";

const UserProgressContext = createContext({
    progress: "", //'cart' / 'checkout',
    showCart: () => {},
    hideCart: () => {},
    showCheckout: () => {},
    hideCheckout: () => {},
});

export function UserProgressContextProvider({ children }) {
    const [progress, setProgress] = useState("");

    function showCart() {
        setProgress("cart");
    }
    function hideCart() {
        setProgress("");
    }
    function showCheckout() {
        setProgress("checkout");
    }
    function hideCheckout() {
        setProgress("");
    }

    const userProgressContext = {
        progress: progress,
        showCart,
        hideCart,
        showCheckout,
        hideCheckout,
    };
    console.log(userProgressContext);
    return (
        <UserProgressContext.Provider value={userProgressContext}>
            {children}
        </UserProgressContext.Provider>
    );
}

export default UserProgressContext;
