import { useCallback, useEffect, useState } from "react";

async function sendHttpRequest(url, config) {
    const response = await fetch(url, config)
    const resData = await response.json();
    if (!response.ok) {
        throw new Error(resData.message || 'Some thing went wrong!')
    }
    return resData
}

export function useHttp(url, config, initial) {
    const [data, setData] = useState(initial)
    const [loading, setLoading] = useState(false)
    const [error, setError] = useState();
    function clearData() {
        setData(initial)
    }
    const sendRequest = useCallback(async function sendRequest(body) {
        setLoading(true)
        try {
            const resData = await sendHttpRequest(url, { ...config, body })
            setData(resData)
        } catch (error) {
            setError(error.message || 'Something went wrong!')
        }
        setLoading(false)
    }, [url, config])

    useEffect(() => {
        if ((config && (config.method === 'GET' || !config.method)) || !config) {
            sendRequest()
        }
    }, [sendRequest, config])

    return {
        data,
        loading,
        error,
        sendRequest,
        clearData
    }
}