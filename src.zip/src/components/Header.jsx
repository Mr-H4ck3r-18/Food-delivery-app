import { useContext } from "react";
import Logo from "../assets/logo.jpg";
import Button from "./UI/Button";
import CartContext from "../store/CartContext";
import UserProgressContext from "../store/UserProgressContext";

export default function Header() {
    const progressCtx = useContext(UserProgressContext);
    const CartCtx = useContext(CartContext);
    const cartCount = CartCtx.items.reduce((totalItems, item) => {
        return totalItems + item.quantity;
    }, 0);
    return (
        <div id="main-header">
            <div id="title">
                <img src={Logo} alt="Logo" />
                <h1>REACTFOOD</h1>
            </div>
            <Button
                textOnly
                onClick={progressCtx.showCart}
            >{`Cart (${cartCount})`}</Button>
        </div>
    );
}
