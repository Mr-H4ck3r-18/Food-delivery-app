import { useContext } from "react";
import { useHttp } from "../../hooks/useHttp";
import Item from "./Item";
import Error from "../Error";
import CartContext from "../../store/CartContext";

const requestConfig = {};
export default function Meals() {
    const CartCtx = useContext(CartContext);

    const {
        error,
        loading,
        data: meals,
    } = useHttp("http://localhost:3000/meals", requestConfig, []);

    if (loading) {
        return <p className="center">fetching the items...</p>;
    }
    if (error) {
        return <Error title="An error occured!" message={error} />;
    }

    return (
        <>
            <ul id="meals">
                {meals.map((meal) => (
                    <Item
                        key={meal.id}
                        meal={meal}
                        onAddCart={CartCtx.addItems}
                    />
                ))}
            </ul>
        </>
    );
}
