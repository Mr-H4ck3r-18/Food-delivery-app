import { currencyFormatter } from "../../currencyFormatter";
import Button from "../UI/Button";

export default function Item({ meal, onAddCart }) {
    function handleclick(meal) {
        onAddCart(meal);
    }

    return (
        <li className="meal-item">
            <article>
                <img src={`http://localhost:3000/${meal.image}`} alt="Item" />
                <div>
                    <h3>{meal.name}</h3>
                    <p className="meal-item-price">
                        {currencyFormatter.format(meal.price)}
                    </p>
                    <p className="meal-item-description">{meal.description}</p>
                    <p className="meal-item-actions">
                        <Button onClick={() => handleclick(meal)}>
                            Add to Cart
                        </Button>
                    </p>
                </div>
            </article>
        </li>
    );
}
