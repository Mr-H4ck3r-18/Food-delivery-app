import { useEffect, useRef } from "react";
import { createPortal } from "react-dom";

export default function Modal({
    open,
    children,
    className = "",
    onClose,
    ...props
}) {
    const dialog = useRef();
    useEffect(() => {
        const modal = dialog.current;
        if (open) {
            modal.showModal();
        } else {
            modal.close();
        }
    }, [open]);
    return createPortal(
        <dialog
            className={`modal ${className}`}
            onClose={onClose}
            ref={dialog}
            {...props}
        >
            {children}
        </dialog>,
        document.getElementById("modal")
    );
}
