import { useContext } from "react";
import CartContext from "../../store/CartContext";
import { currencyFormatter } from "../../currencyFormatter";
import Modal from "../UI/Modal";
import UserProgressContext from "../../store/UserProgressContext";

export default function CartModal() {
    const CartCtx = useContext(CartContext);
    const progressCtx = useContext(UserProgressContext);
    const cartItems = CartCtx.items;
    function handleActionClick(action, meal) {
        if (action === "add") {
            CartCtx.addItems(meal);
        }
        if (action === "remove") {
            CartCtx.removeItem(meal.id);
        }
    }

    const totalPrice = CartCtx.items.reduce((totalPrice, item) => {
        return totalPrice + item.price * item.quantity;
    }, 0);
    return (
        <Modal
            open={progressCtx.progress === "cart"}
            onClose={
                progressCtx.progress === "cart" ? progressCtx.hideCart : null
            }
        >
            <h2>Your Cart</h2>
            <ul>
                {cartItems.map((item) => (
                    <li className="cart-item" key={item.name}>
                        <p>
                            <span>{item.name}-</span>
                            <span>{item.quantity}-</span>
                            <span>{item.price}</span>
                        </p>
                        <p className="cart-item-actions">
                            <button
                                onClick={() =>
                                    handleActionClick("remove", item)
                                }
                            >
                                -
                            </button>
                            <span>{item.quantity}</span>
                            <button
                                onClick={() => handleActionClick("add", item)}
                            >
                                +
                            </button>
                        </p>
                    </li>
                ))}
            </ul>
            <div>
                <p className="cart-total">
                    {currencyFormatter.format(totalPrice)}
                </p>
            </div>

            <p className="modal-actions">
                <button className="text-button" onClick={progressCtx.hideCart}>
                    Close
                </button>
                {cartItems.length > 0 && (
                    <button
                        className="button"
                        onClick={progressCtx.showCheckout}
                    >
                        Go to Checkout
                    </button>
                )}
            </p>
        </Modal>
    );
}
