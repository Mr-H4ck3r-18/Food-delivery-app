import { useContext, useState } from "react";
import Input from "../UI/Input";
import CartContext from "../../store/CartContext";
import { currencyFormatter } from "../../currencyFormatter";
import UserProgressContext from "../../store/UserProgressContext";
import Modal from "../UI/Modal";
import { useHttp } from "../../hooks/useHttp";
import Error from "../Error";

const requestConfig = {
    method: "POST",
    headers: {
        "Content-Type": "application/json",
    },
};
export default function CheckoutModal() {
    const CartCtx = useContext(CartContext);
    const totalPrice = CartCtx.items.reduce((totalPrice, item) => {
        return totalPrice + item.price * item.quantity;
    }, 0);
    const progressCtx = useContext(UserProgressContext);
    const { error, loading, data, clearData, sendRequest } = useHttp(
        "http://localhost:3000/orders",
        requestConfig,
        []
    );
    function handleSubmit(event) {
        event.preventDefault();
        const fd = new FormData(event.target);
        const Data = Object.fromEntries(fd.entries());
        sendRequest(
            JSON.stringify({
                order: {
                    items: CartCtx.items,
                    customer: Data,
                },
            })
        );
    }
    function onFinish() {
        progressCtx.hideCheckout();
        CartCtx.emptyCart();
        clearData();
    }
    let actions = (
        <>
            <button
                type="button"
                className="text-button"
                onClick={progressCtx.hideCheckout}
            >
                Close
            </button>
            <button className="button">Place order</button>
        </>
    );
    if (loading) {
        actions = <span>Sending data...</span>;
    }

    if (data.length != 0 && !error) {
        console.log(data);
        return (
            <Modal
                open={progressCtx.progress === "checkout"}
                onClose={onFinish}
            >
                <h2>Success!</h2>
                <p>We received your Order</p>
                <p className="modal-actions">
                    <button
                        type="button"
                        className="text-button"
                        onClick={onFinish}
                    >
                        Close
                    </button>
                </p>
            </Modal>
        );
    }
    return (
        <Modal
            open={progressCtx.progress === "checkout"}
            onClose={progressCtx.hideCheckout}
        >
            <form onSubmit={handleSubmit}>
                <h2>Checkout</h2>
                <p>Total Amount: {currencyFormatter.format(totalPrice)}</p>
                <Input label="Name" type="text" id="name" />
                <Input label="Email" type="email" id="email" />
                <Input label="Street" type="text" id="street" />
                <div className="control-row">
                    <Input label="Postal code" type="text" id="postal-code" />
                    <Input label="City" type="text" id="city" />
                </div>
                {error && (
                    <Error title="Failed to submit Order" message={error} />
                )}
                <p className="modal-actions">{actions}</p>
            </form>
        </Modal>
    );
}
