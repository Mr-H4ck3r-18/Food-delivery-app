import Header from "./components/Header";
import CartModal from "./components/Cart/CartModal";
import { CartContextProvider } from "./store/CartContext";
import Meals from "./components/Meal/Meals";
import { UserProgressContextProvider } from "./store/UserProgressContext";
import CheckoutModal from "./components/Cart/CheckoutModal";

function App() {
    return (
        <CartContextProvider>
            <UserProgressContextProvider>
                <CartModal />
                <CheckoutModal />
                <Header />
                <Meals />
            </UserProgressContextProvider>
        </CartContextProvider>
    );
}

export default App;
